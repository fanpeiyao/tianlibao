const Directive = function () {}

Directive.install = function (Vue, options) {

}

export default Directive
