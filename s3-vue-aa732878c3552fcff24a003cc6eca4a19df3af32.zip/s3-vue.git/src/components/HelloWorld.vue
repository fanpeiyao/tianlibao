<template>
  <div class="hello">
    <aa></aa>
    <!--<bb></bb>-->
  </div>
</template>

<script>
  import aa from './../mobile/s3-login.vue'
  import bb from './../mobile/s3-firstlogin.vue'
  export default {
    name: 'HelloWorld',
    data () {
      return {

      }
    },
    components:{
      aa
    }
  }
</script>
