<template>
	<el-upload class="" :action="url" on-preview="" on-remove="handleRemove"></el-upload>

</template>
<script>
export default {
	name: 's3-upload',
	data () {
		return {
			
		}
	}
}
</script>
<style>
	
</style>
